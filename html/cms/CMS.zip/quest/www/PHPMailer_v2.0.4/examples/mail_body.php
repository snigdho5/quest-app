<?php

echo "Plase check";

?>