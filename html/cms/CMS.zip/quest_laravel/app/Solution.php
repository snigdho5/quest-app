<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Solution extends Model
{
    //
    protected $table = "solution";
    protected $primaryKey = "docket_no";
}
