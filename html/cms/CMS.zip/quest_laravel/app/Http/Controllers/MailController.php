<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Mail;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class MailController extends Controller {
   public function basic_email(){
      $data = array('name'=>"Helpdesk");
   
      Mail::send(['text'=>'mail'], $data, function($message) {
         $message->to('jghosh.24@gmail.com', 'Tutorials Point')->subject
            ('Laravel Basic Testing Mail');
         $message->from('generation_helpdesk@cesc.co.in','Generation IT Helpdesk');
      });
      echo "Basic Email Sent. Check your inbox.";
   }
   public function html_email($msg,$subject,$to){
      $data = array('name'=>$msg,'to'=>$to,'subject'=>$subject);
      Mail::send('mail', $data, function($message) use($to,$subject) {
         $message->to($to, 'IT Helpdesk');
         $message->subject($subject);
         $message->from('co_helpdesk@rpsg.in','Quest Helpdesk');
      });
   }
   public function html_email_user($msg,$subject,$to){
      $data = array('name'=>$msg,'to'=>$to,'subject'=>$subject);
      Mail::send('mail', $data, function($message) use($to,$subject) {
        // $message->to($to, 'IT Helpdesk');
         $message->to($to);
         $message->subject($subject);
         $message->from('co_helpdesk@rpsg.in','Quest Service Desk');
      });
   }
    public function otp_email($msg,$subject,$to){
      $data = array('name'=>$msg,'to'=>$to,'subject'=>$subject);
      Mail::send('mail', $data, function($message) use($to,$subject) {
        // $message->to($to, 'IT Helpdesk');
         $message->to($to);
         $message->subject($subject);
         $message->from('co_helpdesk@rpsg.in','Quest Service Desk');
      });
   }

   public function attachment_email(){
      $data = array('name'=>"Virat Gandhi");
      Mail::send('mail', $data, function($message) {
         $message->to('abc@gmail.com', 'Tutorials Point')->subject
            ('Laravel Testing Mail with Attachment');
         $message->attach('C:\laravel-master\laravel\public\uploads\image.png');
         $message->attach('C:\laravel-master\laravel\public\uploads\test.txt');
         $message->from('xyz@gmail.com','Virat Gandhi');
      });
      echo "Email Sent with attachment. Check your inbox.";
   }
}
