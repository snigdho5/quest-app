<html>
<h2><?php echo e($name); ?></h2>
</html>